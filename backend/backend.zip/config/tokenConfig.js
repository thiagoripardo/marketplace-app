module.exports = {
    secret : 'chavemuitosecretakappa'
};